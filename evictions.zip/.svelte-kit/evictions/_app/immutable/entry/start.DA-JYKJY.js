import{a as t}from"../chunks/entry.C_w50yuZ.js";export{t as start};
