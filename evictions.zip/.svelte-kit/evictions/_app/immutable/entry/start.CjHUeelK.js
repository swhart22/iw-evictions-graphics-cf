import{a as t}from"../chunks/entry.niVyM9Vt.js";export{t as start};
