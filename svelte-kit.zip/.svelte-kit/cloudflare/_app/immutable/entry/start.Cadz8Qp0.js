import{a as t}from"../chunks/entry.ConN61JK.js";export{t as start};
