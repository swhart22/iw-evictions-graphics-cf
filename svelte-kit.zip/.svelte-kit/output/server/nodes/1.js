

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.Cty8Nfba.js","_app/immutable/chunks/scheduler.C7jYjAr7.js","_app/immutable/chunks/index.BgWy4ugz.js","_app/immutable/chunks/entry.ConN61JK.js","_app/immutable/chunks/index.DsMNHYhv.js"];
export const stylesheets = [];
export const fonts = [];
