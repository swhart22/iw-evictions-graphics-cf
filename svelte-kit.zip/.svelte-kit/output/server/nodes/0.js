

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.B7dGMmc5.js","_app/immutable/chunks/scheduler.C7jYjAr7.js","_app/immutable/chunks/index.BgWy4ugz.js"];
export const stylesheets = [];
export const fonts = [];
